# CS157A-section1-Team5
Database Design and Implementation Project for CS157A: Introduction to Database Management Systems

Daily Recipe
San Jose State University


Team 5
Jiaxiang Guo,
Soyeon Wang,
Gricelda Tecun.
