document.querySelector('.switch').addEventListener('click', function() {
    document.querySelector('.content').classList.toggle('s--signup')
})

